# Alice Android — v0.1.0

هذه هي النواة الأولى لمشروع Alice.

## الهدف
بناء مساعد Android مجاني قدر الإمكان، مع:
- واجهة محادثة
- طبقة صوت
- خدمة foreground للصوت
- بنية قابلة لإضافة Wake Word
- بنية قابلة لإضافة STT محلي
- بنية قابلة لإضافة AI Providers
- لاحقًا Memory / Tools / Plugins / Automation / Media / Coding Agent

## مهم
هذه النسخة ليست Alice النهائية ولا تحتوي بعد على:
- Wake Word حقيقي
- نموذج AI
- STT محلي
- TTS محلي
- Memory
- Plugins

تم وضع الأساس لها الآن حتى لا نضطر لإعادة بناء التطبيق لاحقًا.

## البناء
افتح المجلد في Android Studio، انتظر مزامنة Gradle، ثم:
Build > Build APK(s)

## ملاحظة Android
تشغيل الميكروفون في الخلفية يخضع لقيود Android الحديثة. يجب تشغيل خدمة microphone foreground بالطريقة الصحيحة بعد تفاعل/إذن المستخدم؛ لذلك لن نعتمد على حيلة MacroDroid كأساس للمشروع.

المصدر:
https://developer.android.com/develop/background-work/services/fgs/restrictions-bg-start
