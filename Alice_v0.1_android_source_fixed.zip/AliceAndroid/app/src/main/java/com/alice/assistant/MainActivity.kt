package com.alice.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.alice.assistant.databinding.ActivityMainBinding
import com.alice.assistant.voice.AliceVoiceService

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private val requestCode = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.send.setOnClickListener {
            val text = binding.input.text.toString().trim()
            if (text.isNotEmpty()) {
                binding.conversation.append("\n\nأنت: $text\nأليس: وصلتني رسالتك. محرك الذكاء سيُربط في المرحلة التالية.")
                binding.input.text?.clear()
            }
        }

        binding.voice.setOnClickListener {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.RECORD_AUDIO),
                    requestCode
                )
            } else {
                val intent = Intent(this, AliceVoiceService::class.java)
                ContextCompat.startForegroundService(this, intent)
                binding.status.text = "وضع الصوت مفعّل — Alice جاهزة للاستماع"
                Toast.makeText(this, "تم تشغيل خدمة Alice الصوتية", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
